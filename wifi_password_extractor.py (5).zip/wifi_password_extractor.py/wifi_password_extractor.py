#!/usr/bin/env python3
import subprocess, re, csv
from datetime import datetime

def run_netsh(cmd_args):
    try:
        out = subprocess.check_output(cmd_args, stderr=subprocess.DEVNULL)
        return out.decode('utf-8', errors='ignore')
    except subprocess.CalledProcessError:
        return ""

def get_profiles():
    out = run_netsh(['netsh', 'wlan', 'show', 'profiles'])
    profiles = re.findall(r"All User Profile\s*:\s*(.+)", out, flags=re.IGNORECASE)
    return [p.strip().strip('"') for p in profiles]

def get_password_for_profile(profile):
    out = run_netsh(['netsh', 'wlan', 'show', 'profile', f'name="{profile}"', 'key=clear'])
    m = re.search(r"Key Content\s*:\s*(.+)", out, flags=re.IGNORECASE)
    return m.group(1).strip() if m else None

def main():
    profiles = get_profiles()
    if not profiles:
        print("No Wi-Fi profiles found.")
        return
    results = []
    for p in profiles:
        pwd = get_password_for_profile(p)
        results.append({'profile': p, 'password': pwd if pwd else ""})
    # Print nicely
    maxlen = max(len(r['profile']) for r in results)
    print("\nProfile".ljust(maxlen+2) + "Password")
    print("-"*(maxlen+12))
    for r in results:
        print(r['profile'].ljust(maxlen+2) + (r['password'] or "<no password>"))
    # Save CSV
    fname = f"wifi_passwords_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    with open(fname, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['profile','password'])
        writer.writeheader()
        for r in results:
            writer.writerow(r)
    print(f"\nSaved CSV: {fname}")

if __name__ == "__main__":
    main()
