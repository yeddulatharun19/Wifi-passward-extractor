#!/usr/bin/env python3
"""
wifi_password_gui.py

Simple Tkinter GUI for Windows that lists saved Wi-Fi profiles and shows/copies their passwords.
Run this program with Administrator privileges for full password retrieval.

No external packages required.
"""

import subprocess
import re
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
import csv
import threading

# ------------------ Netsh helper functions ------------------

def run_netsh(args):
    """Run netsh command and return decoded output (or empty string on failure)."""
    try:
        out = subprocess.check_output(args, stderr=subprocess.DEVNULL)
        return out.decode('utf-8', errors='ignore')
    except subprocess.CalledProcessError:
        return ""

def get_profiles():
    """Return a list of saved Wi-Fi profile names (strings)."""
    out = run_netsh(['netsh', 'wlan', 'show', 'profiles'])
    profiles = re.findall(r"All User Profile\s*:\s*(.+)", out, flags=re.IGNORECASE)
    return [p.strip().strip('"') for p in profiles]

def get_password(profile):
    """Return password string or None if not found."""
    out = run_netsh(['netsh', 'wlan', 'show', 'profile', f'name="{profile}"', 'key=clear'])
    m = re.search(r"Key Content\s*:\s*(.+)", out, flags=re.IGNORECASE)
    return m.group(1).strip() if m else None

# ------------------ GUI ------------------

class WifiGui:
    def __init__(self, root):
        self.root = root
        root.title("Wi-Fi Password Extractor")
        root.geometry("520x360")
        root.resizable(False, False)

        # Frame: top controls
        top = ttk.Frame(root, padding=10)
        top.pack(fill="x")

        self.refresh_btn = ttk.Button(top, text="Refresh Profiles", command=self.refresh_profiles)
        self.refresh_btn.pack(side="left")

        self.save_btn = ttk.Button(top, text="Save All to CSV", command=self.save_csv)
        self.save_btn.pack(side="left", padx=(8,0))

        self.status_var = tk.StringVar(value="Ready")
        self.status_label = ttk.Label(top, textvariable=self.status_var)
        self.status_label.pack(side="right")

        # Frame: listbox + password display
        main = ttk.Frame(root, padding=(10,0,10,10))
        main.pack(fill="both", expand=True)

        # Profiles List
        list_frame = ttk.Frame(main)
        list_frame.pack(side="left", fill="y")

        ttk.Label(list_frame, text="Saved Profiles:").pack(anchor="w")
        self.listbox = tk.Listbox(list_frame, width=30, height=15, exportselection=False)
        self.listbox.pack(side="left", fill="y")
        self.listbox.bind("<<ListboxSelect>>", self.on_select)

        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.listbox.yview)
        scrollbar.pack(side="right", fill="y")
        self.listbox.config(yscrollcommand=scrollbar.set)

        # Right: password and actions
        right = ttk.Frame(main, padding=(12,0,0,0))
        right.pack(side="left", fill="both", expand=True)

        ttk.Label(right, text="Password:").pack(anchor="w")
        self.pw_var = tk.StringVar(value="")
        self.pw_entry = ttk.Entry(right, textvariable=self.pw_var, width=30, state="readonly", font=("Consolas", 11))
        self.pw_entry.pack(anchor="w", pady=(0,8))

        self.copy_btn = ttk.Button(right, text="Copy Password", command=self.copy_password)
        self.copy_btn.pack(anchor="w", pady=(0,6))

        ttk.Label(right, text="Notes:").pack(anchor="w", pady=(8,0))
        notes = ("• Run as Administrator to reveal passwords.\n"
                 "• Only use on machines you own or have permission for.")
        ttk.Label(right, text=notes, wraplength=250, foreground="gray").pack(anchor="w")

        # initial load
        self.refresh_profiles()

    def set_status(self, text):
        self.status_var.set(text)
        self.root.update_idletasks()

    def refresh_profiles(self):
        """Refresh the listbox (runs in thread to keep UI responsive)."""
        def task():
            self.set_status("Loading profiles...")
            self.refresh_btn.config(state="disabled")
            self.listbox.delete(0, tk.END)
            profiles = get_profiles()
            if not profiles:
                self.listbox.insert(tk.END, "<no profiles found>")
                self.set_status("No profiles found")
            else:
                for p in profiles:
                    self.listbox.insert(tk.END, p)
                self.set_status(f"{len(profiles)} profile(s) loaded")
            self.refresh_btn.config(state="normal")
        threading.Thread(target=task, daemon=True).start()

    def on_select(self, event):
        sel = self.listbox.curselection()
        if not sel:
            return
        name = self.listbox.get(sel[0])
        if name == "<no profiles found>":
            return
        # fetch password (may require admin), show loading status
        def task():
            self.set_status(f"Getting password for {name}...")
            pwd = get_password(name)
            self.pw_var.set(pwd if pwd else "<no password / not retrievable>")
            self.set_status("Ready")
        threading.Thread(target=task, daemon=True).start()

    def copy_password(self):
        pw = self.pw_var.get()
        if not pw:
            messagebox.showinfo("Copy", "No password to copy.")
            return
        # copy to clipboard using Tkinter
        self.root.clipboard_clear()
        self.root.clipboard_append(pw)
        messagebox.showinfo("Copied", "Password copied to clipboard.")

    def save_csv(self):
        """Save all profiles and passwords to CSV (may show <no password> for some)."""
        def task():
            self.set_status("Saving CSV...")
            self.save_btn.config(state="disabled")
            profiles = get_profiles()
            results = []
            for p in profiles:
                pwd = get_password(p)
                results.append({'profile': p, 'password': pwd if pwd else ""})
            fname = f"wifi_passwords_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            try:
                with open(fname, 'w', newline='', encoding='utf-8') as f:
                    import csv as _csv
                    w = _csv.DictWriter(f, fieldnames=['profile','password'])
                    w.writeheader()
                    for r in results:
                        w.writerow(r)
                messagebox.showinfo("Saved", f"Saved CSV: {fname}")
            except Exception as e:
                messagebox.showerror("Error", f"Could not save CSV: {e}")
            self.save_btn.config(state="normal")
            self.set_status("Ready")
        threading.Thread(target=task, daemon=True).start()

# ------------------ Run app ------------------

if __name__ == "__main__":
    root = tk.Tk()
    app = WifiGui(root)
    root.mainloop()
